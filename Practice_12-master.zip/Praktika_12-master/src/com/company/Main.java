package com.company;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        //Person one = new Person("Smirnov");
        //Person two = new Person("Smirnov Ivan");
        //Person three = new Person("Smirnov Ivan Petrovich");

        //String as = in.nextLine();
        //Adress adress = new Adress(as);

        //Shirt shirts[] = new Shirt[3];
        //for (int i=0; i< shirts.length; i++)
        //    shirts[i]=new Shirt(in.nextLine());

        //for (int i=0; i< shirts.length; i++)
        //    System.out.print(shirts[i]);

        //phoneNumber num1=new phoneNumber("8888005553535");
        //phoneNumber num2=new phoneNumber("+88005553535");
    }
}
