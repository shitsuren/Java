package com.company;

public class Student {
    private int id;
    Student(int id)
    {
        this.id=id;
    }

    public int getId()
    {
        return id;
    }
}